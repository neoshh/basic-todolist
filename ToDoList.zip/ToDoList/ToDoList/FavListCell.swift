//
//  FavListCell.swift
//  ToDoList
//
//  Created by Neo Si Hao on 30/4/19.
//  Copyright © 2019 Neo Si Hao. All rights reserved.
//

import UIKit

class FavListCell: UITableViewCell {

    @IBOutlet weak var item: UILabel!
    
}
